;
<?php $__env->startSection('content'); ?>
  <div class="card-update">
    <form action="" class="form-update">
      
      <label for="">Nama:</label>
      <input type="text" value="<?php echo e(auth()->user()->name); ?>">
      
      <label for="">Password saat ini:</label>
      <input type="password" value="">
      
      <div class="d-flex">
        <a href="/edit-admin/<?php echo e(auth()->user()->id); ?>">
          <button type="button" class="">Edit Data</button>
        </a>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\PPL\PPL-MAPAN\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>