<div class="copyright text-center w-100 bg-dark py-4">
  <h4 class="text-white m-0">MAPAN Copyright © 2024 | Made With Love</h4>
</div><?php /**PATH D:\Tugas\PPL\PPL-MAPAN\resources\views/components/footer.blade.php ENDPATH**/ ?>