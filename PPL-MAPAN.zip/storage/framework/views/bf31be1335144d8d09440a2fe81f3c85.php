
<?php $__env->startSection('content'); ?>
  <div class="hero-profile bg-primary"></div>
  <div class="main-profile-update">
    <div class="container">
      <div class="card-update-profile">
        <h1 class="">Edit Akun</h1>
        <div class="d-flex gap-5 align-items-center">
          <img src="<?php echo e(asset('img/profile/'.auth()->user()->foto_profile)); ?>" class="" alt="">
          <form action="/hapus-foto/<?php echo e(auth()->user()->id); ?>" method="post" class="form-delete-foto">
            <?php echo csrf_field(); ?>
            <button>Hapus</button>
          </form>
        </div>
        <form action="/update-user/<?php echo e(auth()->user()->id); ?>" method="post" class="form-data" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <label for="">File Foto (Kosongi jika tidak ingin mengubah):</label>
          <input type="file" value="" name="foto">
          <label for="">Nama:</label>
          <input type="text" name="name" value="<?php echo e(auth()->user()->name); ?>">
          <label for="">Email:</label>
          <input type="email" name="email" id="" value="<?php echo e(auth()->user()->email); ?>">
          <label for="">Password saat ini:</label>
          <input type="password" name="password" value="">
          <label for="">Password Baru:</label>
          <input type="password" name="confirm_password" value="">
          <label for="">Nomor Telepon:</label>
          <input type="text" name="no_telepon" value="<?php echo e(auth()->user()->no_telepon); ?>">
          <label for="">Deskripsi Diri:</label>
          <textarea name="deskripsi" id="" cols="30" rows="5"><?php echo e(auth()->user()->deskripsi_diri); ?></textarea>
          <label for="">Alamat</label>
          <textarea name="alamat" id="" cols="30" rows="5"><?php echo e(auth()->user()->alamat); ?></textarea>
          <div class="d-flex justify-content-end">
            <button type="submit" class="bg-primary">Simpan Data</button>
          </div>
        </form>
      </div>
    </div>
    <br><br>
    <div class="copyright text-center w-100 bg-dark py-4">
      <h4 class="text-white m-0">MAPAN Copyright © 2024 | Made With Love</h4>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\PPL\PPL-MAPAN\resources\views/updateuser.blade.php ENDPATH**/ ?>