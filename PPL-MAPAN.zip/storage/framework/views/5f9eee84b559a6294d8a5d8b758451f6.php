
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="cover">
    <form name="form-auth" action="/register" method="POST"class="form" id="form-auth">
      <?php echo csrf_field(); ?>
      <div class="head-form">
        <h1 class="title-form">Selamat Datang!</h1>
        <span>Silahkan register akun anda</span>
      </div>
      <div class="flex"><a href="/login"><hr class="hr-grey"></a><hr class="hr-violet"></div>
      <div class="main-form">
        <div class="email input">
          <label class="label" for="email">Email</label>
          <input class="form-input" type="text" name="email" id="email" autofocus>
          <small class="red-text" id="message-email"></small>
        </div>
        <div class="username input">
          <label class="label" for="username">Username</label>
          <input class="form-input" type="text" name="name" id="username">
          <small class="red-text" id="message-username"></small>
        </div>
        <div class="password input">
          <label class="label" for="password">Password</label>
          <input class="form-input" type="password" name="password" id="password">
          <small class="red-text" id="message-password"></small>
        </div>
        <button type="submit" class="btn-form confirm-register">Submit</button>
      </div> 
      <div class="footer-form">
        <p>Sudah punya akun ? <a href="/login" class="log-reg">Masuk</a></p>
        <p>Atau <a href="/" class="back">Kembali ke halaman awal</a></p>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\PPL\PPL-MAPAN\resources\views/auth/register.blade.php ENDPATH**/ ?>